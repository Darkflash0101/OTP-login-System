const express=require('express');
const bodyParser=require('body-parser');
const mongoose=require('mongoose');
const dotenv=require('dotenv');
const cors=require('cors');
const connectDB=require('./dbconnection/dbconnect')
const authRoutes=require('./routes/authRoutes');
const employee=require('./routes/employeeRoutes')

dotenv.config();

const app=express();

connectDB();

const PORT =process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(cors());
app.use('/api/auth',authRoutes);
app.use('/api',employee)


app.listen(PORT ,()=>{
    console.log(`server is running on port http://localhost:${PORT}`);
});

