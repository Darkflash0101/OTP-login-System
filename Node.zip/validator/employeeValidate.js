const {body,validationResult}=require('express-validator');

exports.validateEmployee=[
    body('employeeName').notEmpty().isLength({min:2,max:20}).withMessage('Enter a valid Employee name '),
    body('employeeid').notEmpty().withMessage('Employee ID is required'),
    body('email').isEmail().withMessage('Valid Mail is Required'),
    body('designation').notEmpty().withMessage('designation Name is required'),
    body('unit').notEmpty().withMessage('designation is required'),
    body('department').notEmpty().withMessage('deaprtment is required'),
    (req,res,next)=>{
        const errors =validationResult(req);
        if(!errors.isEmpty()){
            return res.status(400).json({errors:errors.array()})
        }
        next();

    }

]