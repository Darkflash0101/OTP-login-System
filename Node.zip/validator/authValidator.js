const {check ,validationResult}= require('express-validator');


const  validateOTPrequest=[
    check('email')
    .isEmail()
    .withMessage('Please Enter a Valid Email Address')
    .normalizeEmail(),
    (req,res,next)=>{
        const errors = validationResult(req);
        if(!errors.isEmpty()){
            return res.status(400).json({errors:errors.array()});
        }
        next();
    }
];

const validateOTPVerfication=[
    check('email')
    .isEmail()
    .withMessage('Please enter a valid email address')
    .normalizeEmail(),
    
    check('otp')
    .isLength({min:6,max:6})
    .withMessage('OTP should be 6 digits long .')
    .isNumeric()
    .withMessage('OTP should contain only numbers'),
    (req,res,next)=>{
        const errors = validationResult(req);
        if(!errors.isEmpty()){
            return res.status(400).json({errors:errors.array()});
        }
        next();
    }

]

module.exports={
    validateOTPrequest,
    validateOTPVerfication
}