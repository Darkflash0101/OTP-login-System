const express=require('express');
const {createEmployeeController,listEmployee,disableEmployee}=require('../controller/employeecontroller')
const {validateEmployee}=require('../validator/employeeValidate')
const {authToken}= require('../middleware/authtoken')


const router=express.Router();

router.post('/employees',validateEmployee,authToken ,createEmployeeController);

router.get('/employees',listEmployee);

router.post('/disable',disableEmployee)



module.exports=router;
