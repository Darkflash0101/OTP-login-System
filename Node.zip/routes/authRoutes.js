const express=require('express');
const {requestOtpHandler,verifyOTPHandler}=require('../controller/authController')
const {validateOTPrequest,validateOTPVerfication}=require('../validator/authValidator');



const router= express.Router();

router.post('/request-otp',validateOTPrequest,requestOtpHandler)
router.post('/verify-otp',validateOTPVerfication,verifyOTPHandler)

module.exports=router;