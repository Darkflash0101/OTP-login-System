const {User,Employee} =require ('../models/otp');
const {getExpiryTime, generateOTP}=require('../helper/otpHelper')
const {sendMail}=require('../helper/emailSetup');
const json=require('jsonwebtoken');
const { response } = require('express');

require('dotenv').config();

const secretkey=process.env.JWT_SECRET || '5a0a686d003e182296f1bbbc781b96e84e32b10279c1568ce7122ac4bf5e16e5';

const requestOtp= async(email)=>{
    try{
        let user=await User.findOne({email});

        const currentTime=new Date();
        if(user){
            const timediff=(currentTime - user.otpRequests.lastRequestedTime)/(1000*60);
            if(timediff<15 &&user.otpRequests.count>=100){
                return {status:429,message:'OTP request limit exceeded.please try again after 15 minutes.'}
            }
            if(timediff >= 15){
                user.otpRequests.count=0
            }
            user.otp=generateOTP();
            user.otpExpiry=getExpiryTime();
            user.otpRequests.count +=1;
            user.otpRequests.lastRequestedTime=currentTime;
            await user.save();
        }else{
            const newUser=new User({
                email,
                otp:generateOTP(),
                otpExpiry:getExpiryTime(5),
                otpRequests:{
                    count:1,
                    lastRequestedTime :currentTime
                }
            });
            await newUser.save()
        }
        const mailOption={
            from:process.env.EMAIL_USER,
            to:email,
            subject :'Your OTP CODE',
            text:`your OTP Code is :${user.otp}. it will expire in 15 minutes.`
        };
        await sendMail(mailOption);
        return {status:200,message:'OTP generated succesfully and sent to your email'}
    }catch(err){
        console.error('error in requestOtp:',err.message);
        throw new Error('Internal Server Error');
    }
   
}

 const verifyOTP= async (email,otp)=>{
    
    try {
        const user =await User.findOne({email});
        if(!user){
            return {status :404,message:'User Not Found'}
        }
        if(user.isAuthenticated){
            return{status:200,message:'user is already authenticated.'}
        }
        const currentTime=new Date();
        if(user.otp!==otp){
            return{status :400,message:'invalid OTP'};
        }
        /* console.log('Otp Expiry:',user.otpExpiry)
        console.log('current time:',currentTime) */
       
      /*   const expmili=Math.abs(currentTime-user.otpExpiry);
        const expmin=expmili/(1000*60);
        console.log('expmin',expmin); */
        if(currentTime>user.otpExpiry){
            return{status :400,message:'OTP has Expired'};
        }
         const employee= await Employee.findOne({email:email});
        if(!employee){
            throw  new Error('employee not found');
        }
        const token=json.sign(
            {
                name:employee.employeeName,
                employeeid:employee.employeeid
            },
            secretkey  
        )  
        user.isAuthenticated=true;
        await user.save();
        return {status:200,message:"OTP verified Succesfully.User Authenticated", token,employee }
    }catch(error){
    console.log("Error in VerifyOTP");
    throw new Error('Internal Server Error');
    }
 }

module.exports={
    requestOtp,
    verifyOTP
}
