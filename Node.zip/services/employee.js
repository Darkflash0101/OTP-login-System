const { response } = require('express');
const {Employee}=require('../models/otp');
const moment=require('moment');

const isEmployeeExists=async(employeeid,email)=>{
    return await Employee.findOne({$or:[
        {employeid:employeeid},
        {email:email}
       ]
   });
};

const createEmployee=async(EmployeeData)=>{
    const employee=new Employee(EmployeeData);
    await employee.save();
    return employee;
}
const list = async (bodyData, querryData) => {
    const { order,limit, searchKey } = querryData;
    const searchkey  = searchKey;
    let query = {};

    if (searchkey) {
        query.$or = [
            { employeeName: { $regex: searchkey, $options: "i" } },
            { email: { $regex: searchkey, $options: "i" } }
        ];
    }
    const skip = querryData.page ? (parseInt(querryData.page) - 1) * limit : 0;

    const totalEmployees = await Employee.countDocuments(query);
    let employees = await Employee.find(query)
        .sort({ employeeid: parseInt(order) })
        .skip(skip)
        .limit(limit);

        

    employees = employees.map(employee => {
        const updatedAtDate = moment(employee.updatedAt).format('DD MMM YYYY'); 
        const updatedAtTime = moment(employee.updatedAt).format('h:mm A');    

        return {
            ...employee._doc,
            updatedAtDate,
            updatedAtTime
        };
    });

    return { totalEmployees, employees };
};



const toggleEmployee = async (data) => {
  
    
    const employee = await Employee.findOne({
        email: data.email, 
    });
    
    if (employee) {
        
        employee.isActive = !employee.isActive;
        
       
        const updatedEmployee = await employee.save();
        
        
        const updatedAt = moment(updatedEmployee.updatedAt);
        const updatedDate = updatedAt.format('DD MMM YYYY');  
        const updatedTime = updatedAt.format('h:mm A');       
         
        console.log("Updated Date:", updatedDate);
        console.log("Updated Time:", updatedTime);
        
        return {
            message: "Employee Status Changed Successfully",
            employee: updatedEmployee,
            updatedDate,
            updatedTime
        };
    } else {
        return {
            message: 'Employee not found'
        };
    }
};


module.exports={
    isEmployeeExists,
    createEmployee,
    list,
    toggleEmployee
}