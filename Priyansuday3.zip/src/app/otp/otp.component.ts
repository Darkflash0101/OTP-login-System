import { Component } from '@angular/core';
import { OtpServicesService } from '../services/otp-services.service';
import { response } from 'express';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrl: './otp.component.css'
})
export class OtpComponent {
  email:string='';
  message:string='';


constructor(private otpservice:OtpServicesService,private toast:ToastrService,private route:Router){}

sendOTP(){
  if(this.email){
    console.log(this.email);
    this.otpservice.sendOtp(this.email).subscribe(
      (response)=>{
        console.log("response",response);
        if(response.message){
          console.log("response.message",response.message);
          this.message=response.message;
          this.toast.success(response.message);
          this.route.navigate(['/otp-login']);
        }else{
          this.message=response.message;
          this.toast.error(response.message)
        }
      },(error)=>{
        this.toast.error('Error Sending OTP');
      }
    );
  }else{
    this.toast.warning('Please Enter an email address');
  }
}
}
