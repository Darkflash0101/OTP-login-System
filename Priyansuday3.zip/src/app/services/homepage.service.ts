import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomepageService {
  private apiurl='http://localhost:3000/api/employees'

  constructor(private http:HttpClient) { }

  addEmp(employeeData:any,token:string):Observable<any>{
    const headers=new HttpHeaders({'Authorization':`${token}`})
    return this.http.post<any>(this.apiurl,employeeData,{headers});
  }
  getEmployees(order: number, limit: number, page: number, searchKey: any): Observable<any> {
    const url = `${this.apiurl}?order=${order}&limit=${limit}&page=${page}&searchKey=${encodeURIComponent(searchKey)}`;
    console.log("searck key in service :", searchKey)

    return this.http.get(url);
  }
  disableEmployee(email:string):Observable<any>{
    console.log("email",email)
    return this.http.post<any>(`http://localhost:3000/api/disable`,email);
  }
}
