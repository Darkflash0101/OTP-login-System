import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OtpLoginService {

  constructor(private http:HttpClient) { }
  verifyOTP(otp:String,email:string):Observable<any>{
        return this.http.post<any>('http://localhost:3000/api/auth/verify-otp',{otp,email})
  }
}
