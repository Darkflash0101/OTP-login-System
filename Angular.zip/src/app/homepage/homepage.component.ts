import { Component, OnInit } from '@angular/core';
import { HomepageService } from '../services/homepage.service';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrl: './homepage.component.css'
})
export class HomepageComponent implements OnInit {

  empdet:any;
  token:any;
  empname:any;
  status:boolean=true;
  formatdate:any;

  employees: any[] = [];
  totalItems = 0;
  p = 1;
  itemsPerPage = 3;
  searchKey = '';

  employeeData={
    employeeName:'',
    employeeid:'',
    email:'',
    designation:'',
    department:'',
     unit:''
  }


  constructor(private home:HomepageService,private toast:ToastrService){}

   ngOnInit(): void {
    this.empdet=localStorage.getItem('Employee')
    console.log("this.empdet",this.empdet);
    this.empname=this.empdet.employeeName;
    console.log(this.empname);
    this.loadEmployees();  
  }
  addEmployees(){
    this.token=localStorage.getItem('Token');
    this.home.addEmp(this.employeeData,this.token).subscribe((response)=>{
      this.toast.success(response.message);
      this.resetForm();
    })
  }
  loadEmployees(): void {
    const order = -1;
    console.log("payload :",this.searchKey)
    this.home.getEmployees(order, this.itemsPerPage, this.p, this.searchKey).subscribe((response: any) => {
      this.employees = response.data.employees;
      this.totalItems = response.data.totalEmployees;
      this.formatdate=response.data.employees.updatedAt;
      // console.log("data :",response.data);
    });
  }
  resetForm(){
    this.employeeData={
      employeeName:'',
      employeeid:'',
      email:'',
      designation:'',
      department:'',
       unit:''
    };
  }
  onSearch(): void {
    this.p = 1; 
    this.loadEmployees();
  }

  get showingRange(): string {
    const start = (this.p - 1) * this.itemsPerPage + 1;
    const end = Math.min(this.p * this.itemsPerPage, this.totalItems);
    return `Showing ${start} to ${end} of ${this.totalItems} entries`;
  }

  toggleStatus(email: string){
    this.home.disableEmployee(email).subscribe((response)=>{
      console.log('employee status changed',response.employee.isActive);
    },(error)=>{
      console.log('Failed to change employee status',error)
    }
  )
  }

}
