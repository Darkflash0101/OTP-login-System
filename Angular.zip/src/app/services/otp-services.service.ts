import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OtpServicesService {
  private apiUrl="http://localhost:3000/api/auth/request-otp";
  private emails:string='';


  constructor( private http:HttpClient) { }

  sendOtp(email:string):Observable<any>{
    this.emails=email;
    return this.http.post<any>(this.apiUrl,{email});
  }
   getMail(){
    console.log(this.emails);
    return this.emails;
   }
}
