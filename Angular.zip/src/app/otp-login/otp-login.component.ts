import { Component } from '@angular/core';
import { OtpLoginService } from '../services/otp-login.service';
import { ToastrService } from 'ngx-toastr';
import { OtpServicesService } from '../services/otp-services.service';
import { error } from 'console';
import { Router } from '@angular/router';
import { OtpComponent } from '../otp/otp.component';

@Component({
  selector: 'app-otp-login',
  templateUrl: './otp-login.component.html',
  styleUrl: './otp-login.component.css'
})
export class OtpLoginComponent {
  email:string='';
  otp:any;
  otpvalue:string='';
  token:string='';
  employeeDet:any;
  empname:any;

  constructor(private otplog:OtpLoginService,private toast:ToastrService,private otpserve:OtpServicesService,private route:Router){}
  
  verifyOtp(){
    console.log("otpvalue ",this.otpvalue);
    const enteredOtp=String(this.otpvalue);
    console.log("enteredOtp",enteredOtp);

    this.email=this.otpserve.getMail();
    console.log(this.email);
    this.otplog.verifyOTP(enteredOtp,this.email).subscribe((response)=>{
      if(response.message){
        this.toast.success(response.message);
        this.route.navigate(['/homepage']);
        localStorage.setItem('Token',response.token)
        this.empname=response.employee.employeeName;
        localStorage.setItem('Employee',this.empname)
        
      }else{
        this.toast.error(response.message);
      }
    },
  (error)=>{
    this.toast.error("error verifying OTP");
  });

  }



}
