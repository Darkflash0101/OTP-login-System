import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { Router } from 'express';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);  // Inject the router

  const token = localStorage.getItem('Token');
  if (token) {
    return true;
  } else {
    
    router.navigate(['/otp']);
    return false;
  }
};
