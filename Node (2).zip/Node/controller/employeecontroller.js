
const {isEmployeeExists,createEmployee,list,toggleEmployee}=require('../services/employee');

const createEmployeeController=async(req,res)=>{
    try{
        const employeeData=req.body;
        console.log(employeeData.employeeid)
        console.log(employeeData.email)
        const existingEmployee= await isEmployeeExists(employeeData.employeeid,employeeData.email);
        if (existingEmployee){
            return res.status(400).json({error:'employeeId or Email already exists'});
        }
        const employee =await createEmployee(employeeData);
        res.status(201).json({
            success :true,
            data:employee,
            message:'created succesfully'
        });
    }catch(err){
        res.status(500).json({message:'Internal server error',err});
    }
};
const listEmployee=async(req,res)=>{
    try{
        const result = await list(req.body,req.query)
        if(result.totalCount===0){
           return res.status(200).json({
                success :false,
                message:'Records Not found'
            }); 
        }
        return res.status(201).json({
            success :true,
            data:result,
            message:'Records found'
        }); 
    }
    catch{
        res.status(500).json({message:'Internal server error'});
    }
}

const disableEmployee=async(req,res)=>{
   try{
    const employee=await toggleEmployee(req.body);
    console.log('employee',employee)
    return res.status(200).json(employee);
   }
   catch(err){
    res.status(500).json({success:false,message:'Internal server error'})
   }
}

module.exports={
    createEmployeeController,
    listEmployee,
    disableEmployee
}