const { boolean, required } = require('joi');
const mongoose=require('mongoose');
const userSchema= new mongoose.Schema({
    email :{
        type :String ,
        required :true,
        unique:true
    },
    otp:{
        type:String,
        required:false
    },
    otpExpiry:{type:Date,required:false},
    otpRequests:{
        count:{type:Number ,default:0},
        lastRequestedTime:Date
    }
},
{
    isAuthenticated:{
        type:Boolean,
        default:false
    }
});


const employeeSchema = new mongoose.Schema({
    employeeName:{
        type:String,
        required:true,
        /* minlength:2,
        maxlength:20,
        match:/^[a-zA-Z\s]+$/ */
    },
    employeeid:{
        type:String,
        required:true,
        unique:true,
        //minlength:2,
        //maxlength:10,
        
        //match:/^[a-zA-Z0-9\-\/]+$/
    },
    email:{
        type:String,
        required:true,
        unique:true
       /*  minlength:3,
        maxlength:30,
        match:/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[/^[a-zA-Z0-9-.]+$/ */
    },
    designation:{
        type:String,
        required:true,
        /* minlength:2,
        maxlength:20,
        match:/^[a-zA-Z\s]+$/ */
    },
    department:{
        type:String,
        required:true,
        /* minlength:2,
        maxlength:20,
        match:/^[a-zA-Z\s]+$/ */
    },
    unit:{
        type:String,
        required:true,
        /* minlength:2,
        maxlength:20,
        match:/^[a-zA-Z\s]+$/ */
    },
    isActive:{
        type:Boolean,
        default:true
    },
    isAdmin:{
        type:Boolean,
        default:false
    }

},{
    timestamps:true
})



const User=mongoose.model('User',userSchema);
const Employee=mongoose.model('Employee',employeeSchema)

module.exports={
    User,
    Employee,
};