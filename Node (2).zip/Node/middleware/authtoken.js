const  jwt = require('jsonwebtoken');

const secretkey= process.env.JWT_SECRET || '5a0a686d003e182296f1bbbc781b96e84e32b10279c1568ce7122ac4bf5e16e5';

const authToken=(req,res,next)=>{
    const token= req.header('Authorization')
    if(!token){
        return res.status(401).json({error:'Access denied. No Token Provided'});
    }
    try{
        const decode=jwt.verify(token,secretkey);
        if(decode){
            next();
        }
    }catch(err){
      res.status(400).json({error:'Invalid Token.'});
    }
};

module.exports={
    authToken
}