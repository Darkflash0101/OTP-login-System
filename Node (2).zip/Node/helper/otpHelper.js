const generateOTP=()=>{
    return Math.floor(100000+Math.random()*900000).toString()
};

const getExpiryTime = ()=>{

    return new Date(Date.now() +2*60*1000); //this will set the timer as 15 minutes from now
}

module.exports={
    generateOTP,
    getExpiryTime
}