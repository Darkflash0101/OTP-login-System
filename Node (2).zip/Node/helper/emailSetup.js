const nodemailer= require('nodemailer');

const transporter=nodemailer.createTransport({
    service:'Gmail',
    auth:{
    user:process.env.Email_USER ,
    pass:process.env.EMAIL_PASS
    }
})

const sendMail=async (mailOptions)=>{
    try{
        const info= await transporter.sendMail(mailOptions);
        console.log('email sent to :'+info.response);
        return info
    }
    catch(error){
        console.log('error sending email :',error);
        throw new Error('Could not send email' );
    }
};
module.exports={
    sendMail
}